# rm(list = ls())
setwd(dirname(rstudioapi::getSourceEditorContext()$path))
# devtools::install_github("jbodelet/SQL/sql")
library(sql)


#==============
# q= 1 factor:
#==============

sim <- simulate_afm(n = 150, p = 200)

sql <- SQL(sim$data)
sql
abs( cor(sim$factor, sql$factor) )
plot(sql)

x <- sim$data
P <- sql$opt$P
d <- sql$d
lambda <- sql$lambda
G <- sql:::pred_G(x, P, d, lambda)


predict(sql, new_data)

plot( G[[1]][, 1] )

library(gam)
?gam::predict.Gam


 
#==============
# q= 3 factor:
#==============

q <- 2
sim <- simulate_afm(n = 150, p = 200, q = q)

sql <- SQL(sim$data, q = q, tol = 1e-05, d= 6)
sql$EV
abs( cor(sim$factor, sql$factor) )

length(G)





new_data <- matrix(sort(rnorm(1000)))
gen <- predict_generator(new_data, type = "terms")
plot(gen[[1]][, 15] ~ new_data[,1], type = "l")



